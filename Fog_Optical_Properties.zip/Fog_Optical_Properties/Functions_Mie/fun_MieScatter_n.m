function mu = fun_MieScatter_n(lambda, dia, numberDist, den_scat, npar, nmed)

%  lambda        = wavelength in um (eg., lambda = 0.633)
%  dia           = sphere diameters in um (eg., dia_um = 0.0500)
%  numberDist    = particle number distribution 
%  den_scat      = density of scatteres (#/cm^3)
%  npar          = particle refractive index (eg. polystyrene = 1.57)
%  nmed          = medium refractive index (eg., water = 1.33)
%                  Note: npar and nmed can be imaginary numbers.
%  returns musgp = [mus g musp]  
%       mus      = scattering coefficient [m^-1]
%       g        = anisotropy of scattering [dimensionless]
%       musp     = reduced scattering coefficient [m^-1]
%  Uses
%       Mie.m, which uses mie_abcd.m, from Maetzler 2002

ni = numberDist ./ sum(numberDist);   % Normalize so that sum(ni) = 1

Asphere = pi.*(dia./2).^2;      % area (um^2)

m = npar/nmed;                  % ratio of refractive indices

for ii = 1:length(dia)
    x = pi*dia(ii)/(lambda/nmed);       % ratio circumference/wavelength in medium
    u = fun_mie(m, x)';                 % <----- Matlzer's subroutine
    % u = [real(m) imag(m) x qext qsca qabs qb asy qratio];

    qsca(ii) = u(5);                    % scattering efficiency, Qsca
    qabs(ii) = u(6);                    % absorption efficiency, Qabs
    g(ii) = u(8);                       % anisotropy, g
end

mu.mus  = nansum(qsca'.*ni.*den_scat.*Asphere).*10^-6;         % scattering coeff. m^-1
mu.musp = nansum(qsca'.*ni.*den_scat.*Asphere.*(1-g')).*10^-6; % reduced scattering coeff. m^-1
mu.mua  = nansum(qabs'.*ni.*den_scat.*Asphere).*10^-6;         % absorption coeff. m^-1
mu.g = 1 - mu.musp./mu.mus;                                    % anisotropy, g
