function mu = fun_MieScatter_v(lambda, dia, volumeDist, den_scat, npar, nmed)

%  lambda        = wavelength in um (eg., lambda = 0.633)
%  dia           = sphere diameters in um (eg., dia_um = 0.0500)
%  volumeDist    = volume distribution 
%  den_scat       = density of scatteres (#/cm^3)
%  npar          = particle refractive index (eg. polystyrene = 1.57)
%  nmed          = medium refractive index (eg., water = 1.33)
%                  Note: npar and nmed can be imaginary numbers.
%  returns musgp = [mus g musp]  
%       mus      = scattering coefficient [m^-1]
%       g        = anisotropy of scattering [dimensionless]
%       musp     = reduced scattering coefficient [m^-1]
%  Uses
%       Mie.m, which uses mie_abcd.m, from Maetzler 2002

vi = volumeDist;        % volume distribution
vi = vi ./ sum(vi);   % Normalize so that sum(vi) = 1

Vsphere = 4/3*pi.*(dia./2).^3;      % volume of sphere (um^3)
mu.fv = den_scat./10^12./nansum(vi./Vsphere); % volume fraction of spheres in medium (eg., fv = 0.05)

m = npar/nmed;                  % ratio of refractive indices

for ii = 1:length(dia)
    x = pi*dia(ii)/(lambda/nmed);       % ratio circumference/wavelength in medium
    u = fun_mie(m, x)';                 % <----- Matlzer's subroutine
    % u = [real(m) imag(m) x qext qsca qabs qb asy qratio];

    qsca(ii) = u(5);                    % scattering efficiency, Qsca
    qabs(ii) = u(6);                    % absorption efficiency, Qabs
    g(ii) = u(8);                       % anisotropy, g
end

mu.mus  = 3/2.*mu.fv.*nansum(qsca'.*vi./dia).*10^6;         % scattering coeff. m^-1
mu.musp = 3/2.*mu.fv.*nansum(qsca'.*vi./dia.*(1-g')).*10^6; % reduced scattering coeff. m^-1
mu.mua  = 3/2.*mu.fv.*nansum(qabs'.*vi./dia).*10^6;         % absorption coeff. m^-1
mu.g = 1 - mu.musp./mu.mus;                                 % anisotropy, g
