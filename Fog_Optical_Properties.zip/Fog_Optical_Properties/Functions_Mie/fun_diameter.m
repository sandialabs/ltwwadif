function diameter = fun_diameter(Choice)
% Load particle diameter distribution data

if strcmpi(Choice,'SNLFog1')
    % Ref: J. D. VanDerLaan et al., Appl. Opt. 57(19) 2018.
        
    filename = 'data/SNLFog1.mat';
    load(filename,'SNLFog1');
    
    diameter = zeros(length(SNLFog1(:,1)),2);
    diameter(:,1) = SNLFog1(:,1);
    diameter(:,2) = SNLFog1(:,2)./sum(SNLFog1(:,2)); % NUMBER DISTRIBUTION

elseif strcmpi(Choice,'SNLFog2')
    % Ref: B. Z. Bentz et al., Opt. Exp. 2021.

    filename = 'data/SNLFog2.mat';
    load(filename,'SNLFog2');
    
    diameter = zeros(length(SNLFog2(:,1)),2);
    diameter(:,1) = SNLFog2(:,1);
    diameter(:,2) = SNLFog2(:,2)./sum(SNLFog2(:,2)); % NUMBER DISTRIBUTION
    %diameter(:,3) = SNLFog2(:,3)./sum(SNLFog2(:,3)); % VOLUME DISTRIBUTION
    
elseif strcmpi(Choice,'MODTRANModRadFog')
    % MODTRAN Moderate Radiation Fog
    
    % Load
%     filename = 'data/MODTRANModRadFog.mat';
%     load(filename,'MODTRANModRadFog');
%     
%     diameter = zeros(length(MODTRANModRadFog(:,1)),2);
%     diameter(:,1) = MODTRANModRadFog(:,1);
%     diameter(:,2) = MODTRANModRadFog(:,2)./sum(MODTRANModRadFog(:,2)); % NUMBER DISTRIBUTION
    
    % Use Fit: E. P. Shettle and R. W. Fenn, ADA085951, AFGL-TR-79-0214 (1979)
    A = 607.5;
    alpha = 6;
    b = 3.0;
    gamma = 1;
    
    r = [0.01:0.01:40];                 % radius (um) 
    n = A.*r.^alpha.*exp(-b.*r.^gamma); % NUMBER DISTRIBUTION
    diameter(:,1) = 2.*r;
    diameter(:,2) = n./sum(n);
    
    
elseif strcmpi(Choice,'MODTRANHeavyRadFog')
    % MODTRAN Heavy Radiation Fog
    
    % Load
%     filename = 'data/MODTRANHeavyRadFog.mat';
%     load(filename,'MODTRANHeavyRadFog');
%     
%     diameter = zeros(length(MODTRANHeavyRadFog(:,1)),2);
%     diameter(:,1) = MODTRANHeavyRadFog(:,1);
%     diameter(:,2) = MODTRANHeavyRadFog(:,2)./sum(MODTRANHeavyRadFog(:,2)); % NUMBER DISTRIBUTION
    
    % Use Fit: E. P. Shettle and R. W. Fenn, ADA085951, AFGL-TR-79-0214 (1979)
    A = 2.37305;
    alpha = 6;
    b = 1.5;
    gamma = 1;
    
    r = [0.01:0.01:40];                 % radius (um) 
    n = A.*r.^alpha.*exp(-b.*r.^gamma); % NUMBER DISTRIBUTION
    diameter(:,1) = 2.*r;
    diameter(:,2) = n./sum(n);

elseif strcmpi(Choice,'MODTRANModAdvFog')
    % MODTRAN Moderate Advection Fog
    
    % Load
%     filename = 'data/MODTRANModAdvFog.mat';
%     load(filename,'MODTRANModAdvFog');
%     
%     diameter = zeros(length(MODTRANModAdvFog(:,1)),2);
%     diameter(:,1) = MODTRANModAdvFog(:,1);
%     diameter(:,2) = MODTRANModAdvFog(:,2)./sum(MODTRANModAdvFog(:,2)); % NUMBER DISTRIBUTION
    
    % Use Fit: E. P. Shettle and R. W. Fenn, ADA085951, AFGL-TR-79-0214 (1979)
    A = 0.027;
    alpha = 3;
    b = 0.375;
    gamma = 1;
    
    r = [0.01:0.01:40];                 % radius (um) 
    n = A.*r.^alpha.*exp(-b.*r.^gamma); % NUMBER DISTRIBUTION
    diameter(:,1) = 2.*r;
    diameter(:,2) = n./sum(n);

elseif strcmpi(Choice,'MODTRANHeavyAdvFog')
    % MODTRAN Heavy Advection Fog
    
    % Load
%     filename = 'data/MODTRANHeavyAdvFog.mat';
%     load(filename,'MODTRANHeavyAdvFog');
%     
%     diameter = zeros(length(MODTRANHeavyAdvFog(:,1)),2);
%     diameter(:,1) = MODTRANHeavyAdvFog(:,1);
%     diameter(:,2) = MODTRANHeavyAdvFog(:,2)./sum(MODTRANHeavyAdvFog(:,2)); % NUMBER DISTRIBUTION
    
    % Use Fit: E. P. Shettle and R. W. Fenn, ADA085951, AFGL-TR-79-0214 (1979)
    A = 0.06592;
    alpha = 3;
    b = 0.3;
    gamma = 1;
    
    r = [0.01:0.01:40];                 % radius (um) 
    n = A.*r.^alpha.*exp(-b.*r.^gamma); % NUMBER DISTRIBUTION
    diameter(:,1) = 2.*r;
    diameter(:,2) = n./sum(n);

elseif strcmpi(Choice,'GarlandRadFog')
    % Garland Radiation Fog
    % Ref: J. A. Garland, Q. J. R. Meteorol. Soc. 97, 1971.
    
    filename = 'data/GarlandRadFog.mat';
    load(filename,'GarlandRadFog');
    
    diameter = zeros(length(GarlandRadFog(:,1)),2);
    diameter(:,1) = GarlandRadFog(:,1);
    diameter(:,2) = GarlandRadFog(:,2)./sum(GarlandRadFog(:,2)); % NUMBER DISTRIBUTION
    
    % Use Gaussian Fit
%     a = 699.8;
%     b = 0.5741;
%     c = 0.2342;
%     
%     r = [0.01:0.01:30];                 % radius (um) 
%     n = a.*exp(-((r-b)./c).^2);         % NUMBER DISTRIBUTION
%     diameter(:,1) = 2.*r;
%     diameter(:,2) = n./sum(n);

    % Enforce measurement minimum
%     index = find(diameter(:,1) <= 1.2); 
%     diameter = diameter(index(end):end,:);
%     diameter(:,2) = diameter(:,2)./sum(diameter(:,2));

elseif strcmpi(Choice,'GarlandAdvFog')
    % Garland Advection Fog
    % Ref: J. A. Garland, Q. J. R. Meteorol. Soc. 97, 1971.
    
    filename = 'data/GarlandAdvFog.mat';
    load(filename,'GarlandAdvFog');
    
    diameter = zeros(length(GarlandAdvFog(:,1)),2);
    diameter(:,1) = GarlandAdvFog(:,1);
    diameter(:,2) = GarlandAdvFog(:,2)./sum(GarlandAdvFog(:,2)); % NUMBER DISTRIBUTION

    % Use 3 Gaussian fit
%     a1 = 9.507;
%     b1 = 2.015;
%     c1 = 0.7175;
%     
%     a2 = 5.945;
%     b2 = 3.626;
%     c2 = 1.558;
%     
%     a3 = 3.604;
%     b3 = 9.163;
%     c3 = 5.499;
%     
%     r = [0.01:0.01:30];                 % radius (um) 
%     n1 = a1.*exp(-((r-b1)./c1).^2);
%     n2 = a2.*exp(-((r-b2)./c2).^2);
%     n3 = a3.*exp(-((r-b3)./c3).^2);         
%     n = n1 + n2 + n3; % NUMBER DISTRIBUTION
%     diameter(:,1) = 2.*r;
%     diameter(:,2) = n./sum(n);
    
elseif strcmpi(Choice,'KunkelAdvFog')
    % Garland Advection Fog
    % Ref: B. A. Kunkel, ADA119928, AFGL-TR-82-0026, 1982.
    
    filename = 'data/KunkelAdvFog.mat';
    load(filename,'KunkelAdvFog');
    
    diameter = zeros(length(KunkelAdvFog(:,1)),2);
    diameter(:,1) = KunkelAdvFog(:,1);
    diameter(:,2) = KunkelAdvFog(:,2)./sum(KunkelAdvFog(:,2)); % NUMBER DISTRIBUTION

    % Use 2 Gaussian fit
%     a1 = 136.6;
%     b1 = 1.549;
%     c1 = 0.8098;
%     
%     a2 = 60.08;
%     b2 = 6.677;
%     c2 = 3.94;
%     
%     r = [0.01:0.01:30];                 % radius (um) 
%     n1 = a1.*exp(-((r-b1)./c1).^2);
%     n2 = a2.*exp(-((r-b2)./c2).^2);        
%     n = n1 + n2; % NUMBER DISTRIBUTION
%     diameter(:,1) = 2.*r;
%     diameter(:,2) = n./sum(n);

elseif isnumeric(Choice)
    % Case for single diameter
    diameter = [Choice 1];
    
else
    disp('Choice for diameters doesn''t exist, set to 1 um.')
    diameter = [1 1];
    return
end

end



