function n = fun_refractive_index(Choice,lambda)
% Load refractive index data and interpret to specified lambda

if strcmpi(Choice,'water')
    % Ref: G. M. Hale and M. R. Querry, Appl. Opt. 12(3), 1973.
    % Data from https://refractiveindex.info/?shelf=3d&book=liquids&page=water
        
    filename = 'Data/water_n.mat';
    load(filename,'water_n');
    
    % Interpret to lambda 
    temp_r = interp1(water_n(:,1),water_n(:,2),lambda);
    temp_i = interp1(water_n(:,1),water_n(:,3),lambda);
    
    n = temp_r' + 1j .* temp_i';
    
elseif strcmpi(Choice,'FreeSpace')
    
    n = 1.*ones(size(lambda));
    
else
    disp('Choice for n doesn''t exist, set to 1.')
    n = 1.*ones(size(lambda));
    return
end

end



