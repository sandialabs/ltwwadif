function ni = fun_v2n(dia,vi,den_scat)
% Convert from particle volume distribution to particle number distribution

%  dia      = sphere diameters (um)
%  vi       = particle volume distribution
%  den_scat = density of scatteres (#/cm^3)
%  ni       = particle number distribution

Vsphere = 4/3*pi.*dia.^3; % um^3
vi = vi ./ sum(vi); 
ni = den_scat./10^12./nansum(vi./Vsphere).*vi./Vsphere; 
ni = ni./sum(ni); 




