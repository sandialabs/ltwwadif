%% Plotting optial scattering and absorption properties of fog

% B Z. Bentz, B. J. Redman, J. D. van der Laan, K. Westlake, A. Glen, 
% A. L. Sanchez, and J B. Wright, "Light Transport with Weak Angular
% Dependence in Fog," Opt. Express (2021).

load data % generated and saved by fog_optical_properties.m

% Average g over visible wavelenghts
g_avg = mean(mean(data.g(4,data.lambda>=0.380 & data.lambda<=0.750)));

%% Plot Data  
p.figure_path = './figures';      % Save figure path
p.SaveDataTIF = 1;                % 1 to save figures as .png files
p.SaveDataFIG = 0;                % 1 to save figures as .fig files

p.FS = 26;           % font size for titles and ticks
p.axisFS = 18;       % font size for axis
p.legendFS = 18;     % font size for legend
p.linewidth = 4;     % plot line thickness

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
set(gcf,'position',[50,50,450,300])

set(gca,'Box','on','fontsize',0.8*p.axisFS)
yyaxis left
plot(data.lambda,real(data.n_scat),'linewidth',3)
ylabel('real(RI)','fontsize',0.8*p.FS)
yyaxis right
plot(data.lambda,imag(data.n_scat),'-.','linewidth',3)
ylabel('imag(RI)','fontsize',0.8*p.FS)
set(gca,'Ytick',[0.05 0.15 0.25])
xlabel('\lambda (\mum)','fontsize',0.8*p.FS)
grid on
axis tight

% Save figure file
p.file_name = strcat(p.figure_path,'/RI');
if p.SaveDataTIF
    print(p.file_name,'-dtiffn')
    %print(file_name,'-depsc')
end     
if p.SaveDataFIG
    savefig(p.file_name)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
set(gcf,'position',[50,50,600,400])

hold on
for ii = 1:length(data.fog_type)
    p.plot_data = data.diameter{ii}(:,2)./sum(data.diameter{ii}(:,2));
    %plot(data.diameter{ii}(:,1),plot_data,'linewidth',p.linewidth)
    plot(data.diameter{ii}(:,1),p.plot_data./max(p.plot_data),...
                                                   'linewidth',p.linewidth)
end
%h = legend(data.fog_type);
p.h = legend("Advection","SNLFC 1","Radiation","SNLFC 2","Garland");
set(p.h,'Location','east','fontsize',p.legendFS)
set(gca,'XScale','log','Xtick',[10^0 10^1 10^2])
set(gca,'Box','on','fontsize',p.axisFS)
ylabel('$\bar{\it n}$','Interpreter','Latex',...
                       'FontName','Times New Roman','fontsize',p.FS)
xlabel('Diameter (\mum)','fontsize',p.FS)
grid on
%axis([10^-0.25 10^2 0 0.65])
axis([10^-0.25 10^2 0 1])

% Save figure file
p.file_name = strcat(p.figure_path,'/ni');
if p.SaveDataTIF
    print(p.file_name,'-dtiffn')
    %print(file_name,'-depsc')
end     
if p.SaveDataFIG
    savefig(p.file_name)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure
set(gcf,'position',[50,50,750,750])

subplot(3,1,1)
hold on
for ii = 1:length(data.fog_type)
    plot(data.lambda,data.mus(ii,:),'linewidth',p.linewidth)
end
set(gca,'YScale','log','fontsize',p.axisFS)
set(gca,'Box','on','Ytick',[10^-4 10^0])
ylabel('\mu_s (m^{-1})','fontsize',p.FS)
%axis tight
axis([min(data.lambda) max(data.lambda) 10^-4.2 10^2.2])
grid on

subplot(3,1,2)
hold on
for ii = 1:length(data.fog_type)
    plot(data.lambda,data.g(ii,:),'linewidth',p.linewidth)
end
set(gca,'fontsize',p.axisFS)
set(gca,'Box','on','Ytick',[0.1 0.5 0.9])
ylabel('g','fontsize',p.FS)
%axis tight
axis([min(data.lambda) max(data.lambda) 0 1])
grid on

subplot(3,1,3)
hold on
for ii = 1:length(data.fog_type)
    plot(data.lambda,data.mua(ii,:),'linewidth',p.linewidth)
end
set(gca,'YScale','log','fontsize',p.axisFS)
set(gca,'Box','on','Ytick',[10^-8 10^-4 10^0])
ylabel('\mu_a (m^{-1})','fontsize',p.FS)
xlabel('\lambda (\mum)','fontsize',p.FS)
%axis tight
axis([min(data.lambda) max(data.lambda) 10^-9 10^2.5])
grid on

% Save figure file
p.file_name = strcat(p.figure_path,'/mu_s_g_mu_a');
if p.SaveDataTIF
    print(p.file_name,'-dtiffn')
    %print(file_name,'-depsc')
end     
if p.SaveDataFIG
    savefig(p.file_name)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
set(gcf,'position',[50,50,900,600])

subplot(2,1,1)
hold on
for ii = 1:length(data.fog_type)
    plot(data.lambda,data.musp(ii,:),'linewidth',p.linewidth)
end
%h = legend(fog_type);
%h = legend("Advection",'SNLFC 1',"Radiation",'SNLFC 2');   
%set(h,'Location','best','fontsize',legendFS)
set(gca,'Box','on','YScale','log','fontsize',p.axisFS)
set(gca,'Ytick',[10^-4 10^0])
ylabel('\mu_s'' m^{-1}','fontsize',p.FS)
%axis tight
axis([min(data.lambda) max(data.lambda) 10^-4.2 10^2])
grid on

subplot(2,1,2)
hold on
for ii = 1:length(data.fog_type)
    plot(data.lambda,data.mua(ii,:),'linewidth',p.linewidth)
end
set(gca,'YScale','log','fontsize',p.axisFS)
ylabel('\mu_a m^{-1}','fontsize',p.FS)
xlabel('\lambda (\mum)','fontsize',p.FS)
set(gca,'Box','on','Ytick',[10^-8 10^-4 10^0])
%axis tight
axis([min(data.lambda) max(data.lambda) 10^-9 10^2.5])
grid on

% Save figure file
p.file_name = strcat(p.figure_path,'/mu_s_a');
if p.SaveDataTIF
    print(p.file_name,'-dtiffn')
end     
if p.SaveDataFIG
    savefig(p.file_name)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
