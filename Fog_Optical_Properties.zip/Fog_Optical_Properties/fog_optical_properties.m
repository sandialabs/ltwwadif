%% Calculating optial scattering and absorption properties of fog

% B Z. Bentz, B. J. Redman, J. D. van der Laan, K. Westlake, A. Glen, 
% A. L. Sanchez, and J B. Wright, "Light Transport with Weak Angular
% Dependence in Fog," Opt. Express (2021).

% Computational time: 2 hours (Intel(R) Xeon(R) CPU E5-1630 v4 at 3.7 GHz)
% (uncomment lines 16, 34, 35, 36, and 37: 10 sec)

% Mie Code Reference:
% C. M�tzler, �MATLAB functions for Mie scattering and absorption, 
% version 2,� IAP Res. Rep 8, 9 (2002).

%% Environment
clc; clear; close all; 
path(path,'./Functions_MIE');

%% Optical Parameters
data.lambda = [0.2:0.01:12];        % wavelengths (um)
%data.lambda = [0.2:1:12];          % wavelengths (um) (for speed)

data.scat_den = 10^5;   % density of scatteres (1/cm^3)

% Choose scatterers
data.n_scat = fun_refractive_index('water',data.lambda);
data.n_med = fun_refractive_index('FreeSpace',data.lambda);      
data.fog_type = ["MODTRANModAdvFog" "SNLFog1" "MODTRANModRadFog" ...
            "SNLFog2" "GarlandRadFog"];

tic()
for ii = 1:length(data.fog_type)
    
    data.diameter{ii} = fun_diameter(data.fog_type(ii));
    data.mean_diameter(ii) = sum(data.diameter{ii}(:,1).*...
                                 data.diameter{ii}(:,2));

    % Downsample particle distribution for speed 
%     if length(data.diameter{ii}) > 500
%         data.diameter{ii} = downsample(data.diameter{ii},...
%                                  floor(length(data.diameter{ii})/500));
%     end
    
    for jj = 1:length(data.lambda)

        % Scattering parameters from particle number distriubution 
        mu = fun_MieScatter_n(data.lambda(jj),data.diameter{ii}(:,1),...
                              data.diameter{ii}(:,2),data.scat_den,...
                              data.n_scat(jj),data.n_med(jj));

        data.musp(ii,jj) = mu.musp;   % m^-1
        data.mua(ii,jj)  = mu.mua;    % m^-1
        data.mus(ii,jj)  = mu.mus;    % m^-1
        data.g(ii,jj)    = mu.g;
    end
end
toc()

save('data','data')
RUN_ME

%% Clear function paths
rmpath('./Functions_MIE');
